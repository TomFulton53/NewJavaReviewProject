package com.payroll;

public class CommissionEmployee extends Employee {
    private double commissionRate;
    private double[] sales = new double[14];
    public CommissionEmployee(String name, int employeeId, double commissionRate) {
        super(name, employeeId);
        this.commissionRate = commissionRate;
    }

    @Override
    public double calculatePay() {
        return 0;
    }
}
