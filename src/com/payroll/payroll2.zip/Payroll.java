package com.payroll;

public class Payroll {

    public static void main(String[] args) {
        HourlyEmployee employee1 = new HourlyEmployee("Billy Bob Thornton", 12345, 15.50);
        System.out.println(employee1.getName());
        employee1.work(7.5, Day.SUNDAY);
        employee1.work(6, Day.MONDAY);
        employee1.work(4.5, Day.WEDNESDAY);
        employee1.work(4.1, Day.THURSDAY);
        employee1.work(4.1, Day.THURSDAY);
//        employee1.work(5.5, 4);
//        employee1.work(5.5, -7);

        employee1.setName(null);
        System.out.println(employee1.getName());
        System.out.println(employee1.getName().length());

        System.out.println(employee1.getHoursWorked());

//        Day today = Day.WEDNESDAY;
//        System.out.println(today);
//        System.out.println(today.ordinal());
        System.out.println(employee1.calculatePay());

        SalariedEmployee employee2 = new SalariedEmployee("Jane Jones", 34567, 48000);
        System.out.println("Salary for this month is: " + employee2.calculatePay());
    }
}
