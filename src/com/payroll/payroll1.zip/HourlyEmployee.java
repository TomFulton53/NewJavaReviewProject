package com.payroll;

public class HourlyEmployee {
// we need to keep track of hourly rate and  hours
// we need to keep track of employee ID
// also name

    private String name;
    private int employeeId;
    private double hourlyRate;  // 15 digits of precision
    private double hours[] = new double[7];

//    public static final int SUNDAY = 0;
//    public static final int MONDAY = 1;
//    public static final int TUESDAY = 2;
//    public static final int WEDNESDAY = 3;
//    public static final int THURSDAY = 4;
//    public static final int FRIDAY = 5;
//    public static final int SATURDAY = 6;

    public HourlyEmployee(String name, int employeeId, double hourlyRate) {
        setName(name);
        this.employeeId = employeeId;
        this.hourlyRate = hourlyRate;
    }

    public String getName() {return name;}

    public void setName(String name) {
        if (name != null) {
            this.name = name;
        }
        else{
            this.name = "";
        }
    }

    public int getEmployeeId() {return employeeId; }

    public double getHourlyRate() {return hourlyRate;}

    public void setHourlyRate(double hourlyRate) {this.hourlyRate = hourlyRate; }

    public double getHours() {
        double total = 0;
        for (int a = 0; a<hours.length; a++){
            total += hours[a];
        }
        return total;
    }

//    public void setHours(double hours) {
//        this.hours = hours;
//    }

    public void work (double hoursWorked, Day day){
        if (hoursWorked > 0) {
            hours[day.ordinal()] += hoursWorked;  // this is better
        }
    }

    public double calculatePay(){
        return getHours() * hourlyRate;
    }

}
