package com.payroll;

public enum Week {
    WEEK1, WEEK2
}
